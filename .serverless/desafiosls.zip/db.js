module.exports =  {
    database: 'postgres',
    host: 'database-1.ctyqywgbmtff.us-east-1.rds.amazonaws.com',
    port: '5432',
    user: 'postgres',
    password: '4611124',
  }