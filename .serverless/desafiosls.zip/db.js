module.exports =  {
    database: 'desafiosls',
    host: 'database-test.cygfsbo11a6u.us-east-2.rds.amazonaws.com',
    port: '5432',
    user: 'postgres',
    password: 'test123456'
  }
